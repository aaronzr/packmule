from google.cloud import bigquery
from bq_setup import get_bigquery_client
import json


client = get_bigquery_client()

# Replace this example query with your BigQuery SQL Query
QUERY_TO_RUN = '''

WITH students AS (
  SELECT 1 AS student_id, 'John' AS name, 'Freshman' AS year
  UNION ALL
  SELECT 2, 'Alice', 'Sophomore'
  UNION ALL
  SELECT 3, 'Bob', 'Junior'
  -- Add more students as needed
),
courses AS (
  SELECT 101 AS course_id, 'Mathematics' AS course_name, 'Prof. Smith' AS instructor
  UNION ALL
  SELECT 102, 'History', 'Prof. Johnson'
  UNION ALL
  SELECT 103, 'Physics', 'Prof. Brown'
  -- Add more courses as needed
),
enrollments AS (
  SELECT 1 AS student_id, 101 AS course_id, 'A' AS grade
  UNION ALL
  SELECT 1, 102, 'B'
  UNION ALL
  SELECT 1, 103, 'C'
  UNION ALL
  SELECT 2, 101, 'B'
  UNION ALL
  SELECT 2, 102, 'A'
  UNION ALL
  SELECT 2, 103, 'A'
  UNION ALL
  SELECT 3, 101, 'C'
  UNION ALL
  SELECT 3, 102, 'C'
  UNION ALL
  SELECT 3, 103, 'B'
  -- Add more enrollments as needed
)
SELECT 
  s.student_id,
  s.name,
  s.year,
  c.course_id,
  c.course_name,
  c.instructor,
  e.grade
FROM 
  students s
JOIN 
  enrollments e ON s.student_id = e.student_id
JOIN 
  courses c ON e.course_id = c.course_id
ORDER BY 
  s.student_id, c.course_id;
  
'''

def execute_query(query):
    query_job = client.query(query) 
    return query_job.result()

def print_results(results, print_as_array=True):
    column_names = [field.name for field in results.schema]

    if print_as_array:
        dict_results = [dict(zip(column_names, row)) for row in results]
        print(json.dumps(dict_results, indent=4))
    else:
        header = " | ".join(column_names)
        print(header)
        print("-" * len(header))

        for row in results:
            formatted_row = " | ".join(str(item) for item in row)
            print(formatted_row)

def main():
    results = execute_query(QUERY_TO_RUN)
    print_results(results, print_as_array=True)

if __name__ == '__main__':
    main()

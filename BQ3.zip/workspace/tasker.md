**Documentation for BigQuery Query**

**Purpose:**

This query retrieves student learning data, including student information, course details, and enrollment grades.

**Data Sources:**

* **students:** A table containing student information (student_id, name, year).
* **courses:** A table containing course information (course_id, course_name, instructor).
* **enrollments:** A table containing enrollment information (student_id, course_id, grade).

**Query Structure:**

The query consists of three Common Table Expressions (CTEs):

* **students:** Defines the student table with sample data.
* **courses:** Defines the course table with sample data.
* **enrollments:** Defines the enrollment table with sample data.

The main query then joins the three CTEs to retrieve the desired data:

* **JOIN students s ON s.student_id = e.student_id:** Joins the students table (s) with the enrollments table (e) on the student_id column.
* **JOIN courses c ON e.course_id = c.course_id:** Joins the enrollments table (e) with the courses table (c) on the course_id column.

**Output Columns:**

The query returns the following columns:

* **s.student_id:** Student ID
* **s.name:** Student name
* **s.year:** Student year
* **c.course_id:** Course ID
* **c.course_name:** Course name
* **c.instructor:** Course instructor
* **e.grade:** Enrollment grade

**Ordering:**

The results are ordered by student_id and course_id.

**Example Usage:**

```
SELECT
  *
FROM
  `my_dataset.student_learning_data`;
```

**Additional Notes:**

* The sample data in the CTEs can be replaced with actual data from your tables.
* You can add additional columns to the output by including them in the SELECT clause.
* You can filter the results using the WHERE clause.
* You can sort the results using the ORDER BY clause.
#!/bin/python3
import re
import random
from datetime import datetime, timedelta
import faker

# This script contains example functions that were used (with the help of gpt4)
# to generate insert statements for a veterinary database, these won't work for
# your assigned database but might give you some ideas about how to approach your generation

def generate_treatments_from_appointments(sql_file_path, output_file_path):
    # Define probabilities and treatment descriptions for different appointment reasons
    appointment_reasons_with_treatments = {
        "Behavioral Assessment": ["Behavioral therapy session", "Prescribed anxiety medication"],
        "X-Ray Examination": ["Conducted X-Ray for bone fracture", "X-Ray imaging for internal injury"],
        "Allergy Consultation": ["Administered allergy tests", "Prescribed allergy medication"],
        "Ultrasound": ["Abdominal ultrasound for organ assessment", "Cardiac ultrasound"],
        "Flea and Tick Treatment": ["Applied topical flea and tick treatment", "Administered oral flea and tick preventive"],
        "Injury Treatment": ["Wound cleaning and suturing", "Splint application for limb injury"],
        "Nutritional Advice": ["Dietary consultation and plan formulation", "Prescribed nutritional supplements"],
        "Emergency Care": ["Critical condition stabilization", "Emergency surgery if needed"],
        "Vaccination": ["Administered routine vaccinations", "Booster vaccine shots"],
        "Eye Problem Assessment": ["Comprehensive eye examination", "Prescribed eye medication"],
        "Ear Infection Treatment": ["Ear examination and cleaning", "Prescribed ear infection medication"],
        "Dental Cleaning": ["Teeth cleaning and oral examination", "Dental scaling and polishing"],
        "Skin Rash Examination": ["Skin examination and biopsy if needed", "Prescribed topical ointment"],
        "Limping Investigation": ["Joint and limb examination", "Recommended physical therapy"],
        "Weight Management Consultation": ["Weight assessment and diet planning", "Prescribed weight management medication"],
        "Senior Pet Wellness Check": ["Comprehensive health examination", "Bloodwork and age-related screenings"],
        "Heartworm Testing": ["Heartworm antigen test", "Prescription for heartworm preventive medication"],
        "Spay/Neuter Surgery": ["Performed spay or neuter surgery", "Post-operative care and monitoring"],
        "Gastrointestinal Issue": ["Gastrointestinal system examination", "Prescribed medication for GI distress"],
        "Routine Check-Up": ["General health assessment", "Updating vaccination and medical records"]
    }




    # General treatment option if specific treatments are not defined
    general_treatment = "General medical treatment provided"

    # Read the appointments data from the SQL file
    with open(sql_file_path, 'r') as file:
        appointments_sql = file.read()

    # Extracting appointment data (ID and reason) using regex
    appointment_regex = r"\((\d+), \d+, \d+, '\d{4}-\d{2}-\d{2}', '\d{2}:\d{2}:\d{2}', '([^']+)'\)"
    appointments = re.findall(appointment_regex, appointments_sql)

    # Generate treatments for appointments
    treatments_data = []
    treatment_id = 1
    for appointment in appointments:
        appointment_id, reason = appointment

        available_treatments = appointment_reasons_with_treatments.get(reason, [general_treatment])
        num_treatments = random.randint(0, len(available_treatments))  # Randomly select the number of treatments

        selected_treatments = random.sample(available_treatments, num_treatments)  # Select unique treatments

        for treatment in selected_treatments:
            treatments_data.append((treatment_id, int(appointment_id), treatment))
            treatment_id += 1

    # Construct SQL insert statements for Treatments
    treatments_sql_insert_statements = "INSERT INTO Treatments (TreatmentID, AppointmentID, Description) VALUES\n"
    treatments_sql_insert_statements += ",\n".join([f"({treatment[0]}, {treatment[1]}, '{treatment[2]}')" for treatment in treatments_data])
    treatments_sql_insert_statements += ";"

    # Save to a file
    with open(output_file_path, 'w') as file:
        file.write(treatments_sql_insert_statements)

# Example usage:
# generate_treatments_from_appointments('appointments.sql', 'treatments.sql')

def generate_treatment_inventory(treatments_file, inventory_file, output_file):
    # Load treatments and inventory data from SQL files
    with open(treatments_file, 'r') as file:
        treatments_sql = file.read()
    with open(inventory_file, 'r') as file:
        inventory_sql = file.read()

    # Extract treatment ID and descriptions
    treatment_regex = r"\((\d+), \d+, '([^']+)'\)"
    treatments = re.findall(treatment_regex, treatments_sql)

    # Extract inventory ID and names
    inventory_regex = r"\((\d+), '([^']+)', \d+, '[^']+', \d+\)"
    inventory = re.findall(inventory_regex, inventory_sql)

    # Create mappings from treatment descriptions to IDs and inventory names to IDs
    treatment_desc_to_id = {desc: int(tid) for tid, desc in treatments}
    inventory_name_to_id = {name: int(iid) for iid, name in inventory}

    # Define treatment to inventory mapping
    treatment_inventory_mapping = {
        "Behavioral therapy session": [],
        "Prescribed anxiety medication": ["Trazodone"],
        "Conducted X-Ray for bone fracture": ["Digital X-Ray Plates"],
        "X-Ray imaging for internal injury": ["Digital X-Ray Plates"],
        "Administered allergy tests": [],
        "Prescribed allergy medication": ["Fexofenadine", "Hydroxyzine"],
        "Abdominal ultrasound for organ assessment": ["Ultrasound Machine"],
        "Cardiac ultrasound": ["Ultrasound Machine"],
        "Applied topical flea and tick treatment": ["Flea and Tick Collar", "Fipronil Spot-On"],
        "Administered oral flea and tick preventive": ["Fipronil Spot-On"],
        "Wound cleaning and suturing": ["Suture Kit with Various Needle Sizes", "Iodine Disinfectant Solution", "Sterile Gauze Pads"],
        "Splint application for limb injury": ["Orthopedic Splint Kit"],
        "Dietary consultation and plan formulation": [],
        "Prescribed nutritional supplements": ["Multivitamin Supplements"],
        "Critical condition stabilization": ["Medical Examination Kit", "Surgical Instruments Set"],
        "Performed GDV Surgery": ["Surgical Instruments Set", "Post-Operative Recovery Kit"],
        "Foreign Object Surgical Removal": ["Surgical Instruments Set", "Digital X-Ray Plates", "Post-Operative Recovery Kit"],
        "Cesarean Section for Complicated Birth": ["Surgical Instruments Set", "Ultrasound Machine", "Post-Operative Recovery Kit"],
        "Orthopedic Surgery for Fracture Repair": ["Orthopedic Splint Kit", "Surgical Instruments Set", "Digital X-Ray Plates"],
        "Surgical Laceration Repair": ["Suture Kit with Various Needle Sizes", "Iodine Disinfectant Solution", "Sterile Gauze Pads"],
        "Administered routine vaccinations": ["Rabies Vaccine", "Distemper Vaccine", "Parvovirus Vaccine", "Leptospirosis Vaccine", "Bordetella Vaccine", "Lyme Disease Vaccine"],
        "Booster vaccine shots": ["Rabies Vaccine", "Distemper Vaccine", "Parvovirus Vaccine"],
        "Comprehensive eye examination": [],
        "Prescribed eye medication": ["Ophthalmic Solution"],
        "Ear examination and cleaning": [],
        "Prescribed ear infection medication": ["Otic Solution"],
        "Teeth cleaning and oral examination": ["Dental Scaling Tools", "Enzymatic Dental Toothpaste"],
        "Dental scaling and polishing": ["Dental Scaling Tools"],
        "Skin examination and biopsy if needed": [],
        "Prescribed topical ointment": ["Hydrocortisone Cream"],
        "Joint and limb examination": [],
        "Recommended physical therapy": [],
        "Weight assessment and diet planning": [],
        "Prescribed weight management medication": ["Metformin"],
        "Comprehensive health examination": ["Medical Examination Kit"],
        "Bloodwork and age-related screenings": ["Medical Examination Kit"],
        "Heartworm antigen test": ["Heartworm Antigen Test Kit"],
        "Prescription for heartworm preventive medication": ["Ivermectin"],
        "Performed spay or neuter surgery": ["Surgical Instruments Set", "Post-Operative Recovery Kit"],
        "Post-operative care and monitoring": ["Post-Operative Recovery Kit"],
        "Gastrointestinal system examination": [],
        "Prescribed medication for GI distress": ["Probiotics"],
        "General health assessment": ["Medical Examination Kit"],
        "Updating vaccination and medical records": [],
        "Pain Management": ["Carprofen Pain Reliever", "Paracetamol", "Gabapentin"],
        "Infection Treatment": ["Amoxicillin Antibiotics", "Cephalexin Antibiotic", "Clindamycin Antibiotic"],
        "Chronic Condition Management": ["Insulin", "Thyroxine", "Prednisone"],
        "Wound Care": ["Iodine Disinfectant Solution", "Sterile Gauze Pads"]
    }


    # Generate TreatmentInventory insert statements
    treatment_inventory_inserts = []
    for treatment in treatments:
        treatment_id, treatment_desc = treatment
        inventory_items = treatment_inventory_mapping.get(treatment_desc, [])

        if inventory_items:
            # Randomly select a number of items to assign (at least one)
            num_items = random.randint(1, len(inventory_items))
            selected_items = random.sample(inventory_items, num_items)

            for item in selected_items:
                inventory_id = inventory_name_to_id.get(item)
                if inventory_id:
                    quantity_used = 1  # Assuming quantity is always 1
                    treatment_inventory_inserts.append((int(treatment_id), inventory_id, quantity_used))

    # Construct SQL insert statements for TreatmentInventory
    sql_insert_statements = "INSERT INTO TreatmentInventory (TreatmentID, ItemID, QuantityUsed) VALUES\n"
    sql_insert_statements += ",\n".join([f"({record[0]}, {record[1]}, {record[2]})" for record in treatment_inventory_inserts])
    sql_insert_statements += ";"

    # Save to a file
    with open(output_file, 'w') as file:
        file.write(sql_insert_statements)

# Example usage
# generate_treatment_inventory('treatments.sql', 'inventory.sql', 'treatment_inventory.sql')

def generate_billing_entries(appointments_file, billing_output_file):
    # Read appointments data
    with open(appointments_file, 'r') as file:
        appointments_sql = file.read()

    # Extracting appointment data (ID and date) using regex
    appointment_regex = r"\((\d+), \d+, \d+, '(\d{4}-\d{2}-\d{2})', '[^']+', '[^']+'\)"
    appointments = re.findall(appointment_regex, appointments_sql)

    # Generate Billing insert statements
    billing_inserts = []
    bill_id = 1
    void_bill_id = random.randint(1, len(appointments))  # Randomly select one bill to be 'Void'

    for appointment in appointments:
        appointment_id, date_str = appointment
        appointment_date = datetime.strptime(date_str, '%Y-%m-%d')

        # Random billing date within 0-14 days after appointment date
        billing_date = appointment_date + timedelta(days=random.randint(0, 14))

        # Random total amount (for example, between 50 to 500)
        total_amount = round(random.uniform(50, 500), 2)

        # Random status (1: Paid, 2: Pending, 3: Overdue, 4: Void)
        status_id = 4 if bill_id == void_bill_id else random.choice([1, 2, 3])

        billing_inserts.append((bill_id, int(appointment_id), total_amount, billing_date.strftime('%Y-%m-%d'), status_id))
        bill_id += 1

    # Construct SQL insert statements for Billing
    billing_sql_insert_statements = "INSERT INTO Billing (BillID, AppointmentID, TotalAmount, DateIssued, StatusID) VALUES\n"
    billing_sql_insert_statements += ",\n".join([f"({record[0]}, {record[1]}, {record[2]}, '{record[3]}', {record[4]})" for record in billing_inserts])
    billing_sql_insert_statements += ";"

    # Save to a file
    with open(billing_output_file, 'w') as file:
        file.write(billing_sql_insert_statements)

# Example usage
# generate_billing_entries('appointments.sql', 'billing.sql')

def generate_emergency_contacts(output_file, number_of_pets=98):
    # Initialize Faker for generating realistic contact names and phone numbers
    fake = faker.Faker()

    # Prepare SQL insert statements
    emergency_contact_inserts = []

    for pet_id in range(1, number_of_pets + 1):
        contact_name = fake.name()  # Generate a random name
        phone_number = fake.phone_number()  # Generate a random phone number

        emergency_contact_inserts.append((pet_id, pet_id, contact_name, phone_number))

    # Construct SQL insert statements for EmergencyContacts
    emergency_contacts_sql_insert_statements = "INSERT INTO EmergencyContacts (ContactID, PetID, ContactName, Phone) VALUES\n"
    emergency_contacts_sql_insert_statements += ",\n".join([f"({record[0]}, {record[1]}, '{record[2]}', '{record[3]}')" for record in emergency_contact_inserts])
    emergency_contacts_sql_insert_statements += ";"

    # Save to a file
    with open(output_file, 'w') as file:
        file.write(emergency_contacts_sql_insert_statements)

# Example usage
# generate_emergency_contacts('emergency_contacts.sql')

# Function to generate vaccination records
def generate_vaccinations(pets_file_path, output_file_path):
    # Initialize Faker
    fake = faker.Faker()

    # Define vaccination types for different species
    vaccinations_by_species = {
        "Dog": ["Rabies Vaccine", "Distemper Vaccine", "Parvovirus Vaccine", "Leptospirosis Vaccine", "Bordetella Vaccine", "Lyme Disease Vaccine"],
        "Cat": ["Rabies Vaccine", "Feline Distemper Vaccine", "Feline Leukemia Vaccine"],
        "Bird": ["Psittacosis Vaccine"],
        "Rabbit": ["Myxomatosis Vaccine", "VHD Vaccine"],
        "Hamster": [],  # Typically, hamsters do not require vaccinations
        "Fish": []  # Fish do not require vaccinations
    }

    # Read the pets data from the SQL file
    with open(pets_file_path, 'r') as file:
        pets_sql = file.read()

    # Extracting pet data (ID and species) using regex
    pet_regex = r"\((\d+), \d+, '[^']+', '([^']+)', '[^']+', '([^']+)'\)"
    pets = re.findall(pet_regex, pets_sql)

    # Generate vaccination records for pets
    vaccination_data = []
    vaccination_id = 1
    for pet in pets:
        pet_id, species, dob = pet
        pet_id = int(pet_id)
        dob = datetime.strptime(dob, '%Y-%m-%d')

        # Select vaccinations based on species
        possible_vaccinations = vaccinations_by_species.get(species, [])

        # Assign vaccinations
        for vaccine in possible_vaccinations:
            vaccination_date = dob + timedelta(weeks=random.randint(8, 52))  # Assuming initial vaccination within the first year
            next_due_date = vaccination_date + timedelta(weeks=52)  # Assuming annual vaccinations
            vaccination_data.append((vaccination_id, pet_id, vaccine, vaccination_date.strftime('%Y-%m-%d'), next_due_date.strftime('%Y-%m-%d')))
            vaccination_id += 1

    # Construct SQL insert statements for Vaccinations
    vaccinations_sql_insert_statements = "INSERT INTO Vaccinations (VaccinationID, PetID, VaccineName, VaccinationDate, NextDueDate) VALUES\n"
    vaccinations_sql_insert_statements += ",\n".join([f"({record[0]}, {record[1]}, '{record[2]}', '{record[3]}', '{record[4]}')" for record in vaccination_data])
    vaccinations_sql_insert_statements += ";"

    # Save to a file
    with open(output_file_path, 'w') as file:
        file.write(vaccinations_sql_insert_statements)

# Example usage
generate_vaccinations('pets.sql', 'vaccinations.sql')
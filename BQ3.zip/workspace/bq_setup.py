#!/bin/python3
from google.cloud import bigquery
from google.oauth2 import service_account

# Path to the service account key file
SERVICE_ACCOUNT_FILE = 'bigquery-api-keys.json'

def get_bigquery_client():
    # Explicitly create credentials from the service account file
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE,
    )
    
    # Create a BigQuery client using the credentials
    client = bigquery.Client(credentials=credentials, project=credentials.project_id)
    return client

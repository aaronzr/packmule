package tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import com.sphere_engine.Calculator;

public class CalculatorTest
{

    @Test
    public void testCreate()
    {
        Calculator c = new Calculator();
        assertNotNull(c);
    }

    @Test
    public void testAdd()
    {
        Calculator c = new Calculator();
        assertEquals(5, c.add(2, 3));
    }
}
Welcome to Java project example. Boilerplate code is setup to get you started in `Main.java`. Once you've familiarized yourself with the environment, feel free to modify existing files or add new ones to build your app.

Run
-----------------
Example is located in `Main.java` file. 
It will run a program that prints out a "Hello World" message.

Press `Run` button to run the example.


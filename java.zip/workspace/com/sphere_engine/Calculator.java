package com.sphere_engine;

public class Calculator
{
	public int add(int a, int b)
	{
		// Write your code below.
		//
		// Correct solution:
        // return a+b;
		return 0;
	}
}

#!/bin/bash

PATH=/opt/jdk/bin:$PATH

java -jar junit-platform-console-standalone-1.9.0.jar --disable-banner -cp "build/test" --scan-classpath --reports-dir=./reports

cp ./reports/TEST-junit-jupiter.xml $SE_PATH_UNIT_TESTS_REPORT

exit 0;

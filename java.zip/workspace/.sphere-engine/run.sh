#!/bin/bash

PATH=/opt/jdk/bin:$PATH
java -cp "build/run" Main

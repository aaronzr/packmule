#!/bin/bash

PATH=/opt/jdk/bin:$PATH
javac -d "build/run" -cp "/opt/jdk/libs/*" -encoding utf8 -J-client *.java com/sphere_engine/*.java 1>&-
ret=$?
if [[ "$ret" != "0" ]]; then
  se_utils_cli scenario_result status "BE"
fi

exit 0;
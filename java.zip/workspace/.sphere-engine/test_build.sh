#!/bin/bash

PATH=/opt/jdk/bin:$PATH

javac -d "build/test" -cp "/spoj/*:/opt/jdk/libs/*:." -cp junit-platform-console-standalone-1.9.0.jar -encoding utf8 -J-client com/sphere_engine/*.java tests/*.java 1>&-
ret=$?
if [[ "$ret" != "0" ]]; then
  se_utils_cli scenario_result status "BE"
fi

exit 0;
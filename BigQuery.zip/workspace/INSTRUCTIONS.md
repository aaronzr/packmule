## BigQuery SQL Query Creation Instructions

### Task Overview

Your task is to create a BigQuery SQL query using the provided dataset. You will replace only the query portion in the `main.py` script and then run it to ensure it executes correctly.

### Steps for Taskers

1. **Understand the Dataset**: Review the schema and data available in the provided BigQuery dataset. Identify the key columns and relationships relevant to the task.

2. **Craft Your Query**:
   - Write a BigQuery SQL query that meets the requirements of the specified task type. This might involve selecting specific fields, aggregating data, or filtering based on certain criteria.
   - Replace the existing `QUERY_TO_RUN` string in `main.py` with your new query. Ensure that you only modify this query string and nothing else in the script.

3. **Execute Your Query**:
   - Run `main.py` using the 'Run' button to execute your query.
   - Check the output to ensure that it matches the expected results based on the task requirements.

### Important Notes

- **Modify Only the Query**: Do not alter any other part of the `main.py` script aside from the `QUERY_TO_RUN` string.
- **Test Thoroughly**: After inserting your query into `main.py`, test it thoroughly to ensure it works as expected and retrieves the correct data.

By following these steps, you can efficiently create and test BigQuery SQL queries for the provided dataset within the scope of the given task.

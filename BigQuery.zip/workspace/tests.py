# tests.py
import unittest
from main import execute_query, print_results, QUERY_TO_RUN
from bq_setup import get_bigquery_client

class BigQueryScriptTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = get_bigquery_client()

    def test_query_modification_only(self):
        original_globals = ['execute_query', 'print_results', 'client', 'json']
        import main
        current_globals = [func for func in dir(main) if callable(getattr(main, func)) or not func.startswith('__')]

        self.assertTrue(all(elem in current_globals  for elem in original_globals),
                        'Global scope modification detected. Only QUERY_TO_RUN should be changed.')

    def test_query_structure(self):
        required_clauses = ['SELECT', 'FROM', 'WHERE', 'GROUP BY', 'ORDER BY', 'LIMIT']
        for clause in required_clauses:
            self.assertIn(clause, QUERY_TO_RUN.upper(),
                          f"The query is missing the required clause: {clause}")

    def test_query_execution(self):
        try:
            results = execute_query(QUERY_TO_RUN)
            self.assertIsNotNone(results, 'Query execution returned no results, expected some results.')
        except Exception as e:
            self.fail(f"Query execution failed with an exception: {e}")

    def test_result_structure(self):
        results = execute_query(QUERY_TO_RUN)
        expected_columns = ['name', 'class', 'total_badges_awarded']
        results_columns = [field.name for field in results.schema]

        self.assertEqual(expected_columns, results_columns,
                         'The structure of the query results does not match the expected columns.')

if __name__ == '__main__':
    unittest.main()

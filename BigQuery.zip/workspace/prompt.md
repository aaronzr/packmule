 I have a shopping list of different products. Below is the bigQuery for the list, kindly help to generate unit test for the query below. Make sure each test cover the edge cases of having 0 item from each category.
```BigQuery
WITH items AS (
  SELECT 'Apples' AS item, 2 AS quantity, 'Produce' AS category
  UNION ALL
  SELECT 'Milk', 1, 'Dairy'
  UNION ALL
  SELECT 'Bread', 2, 'Bakery'
  UNION ALL
  SELECT 'Eggs', 1, 'Dairy'
  -- Add more items as needed
)

SELECT 
  category,
  item,
  SUM(quantity) AS total_quantity
FROM 
  items
GROUP BY 
  category,
  item
ORDER BY 
  category,
  item;

```
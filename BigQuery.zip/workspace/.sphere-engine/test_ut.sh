#!/bin/bash

python3 -m xmlrunner --output-file $SE_PATH_UNIT_TESTS_REPORT
exit 0;
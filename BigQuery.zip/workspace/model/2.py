
# **Unit Test 2: Empty Dairy Category**

# ```python
import unittest
from google.cloud import bigquery

class ShoppingListQueryTest(unittest.TestCase):

    def test_empty_dairy(self):
        # Create a BigQuery client
        client = bigquery.Client()

        # Create a query job
        query_job = client.query(
            """
            WITH items AS (
              SELECT 'Apples' AS item, 2 AS quantity, 'Produce' AS category
              UNION ALL
              SELECT 'Bread', 2, 'Bakery'
            )

            SELECT 
              category,
              item,
              SUM(quantity) AS total_quantity
            FROM 
              items
            GROUP BY 
              category,
              item
            ORDER BY 
              category,
              item;
            """
        )

        # Get the results
        results = list(query_job.result())

        # Assert that the results are correct
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]['category'], 'Bakery')
        self.assertEqual(results[0]['item'], 'Bread')
        self.assertEqual(results[0]['total_quantity'], 2)
        self.assertEqual(results[1]['category'], 'Produce')
        self.assertEqual(results[1]['item'], 'Apples')
        self.assertEqual(results[1]['total_quantity'], 2)
# ```

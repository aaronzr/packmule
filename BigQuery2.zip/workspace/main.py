from google.cloud import bigquery
from bq_setup import get_bigquery_client
import json


client = get_bigquery_client()

# Replace this example query with your BigQuery SQL Query
QUERY_TO_RUN = '''
SELECT
  name,
  class,
  COUNT(*) AS total_badges_awarded
FROM
  `bigquery-public-data.stackoverflow.badges`
WHERE
  EXTRACT(YEAR FROM date) = 2020
GROUP BY
  name, class
ORDER BY
  total_badges_awarded DESC;
'''

def execute_query(query):
    query_job = client.query(query) 
    return query_job.result()

def print_results(results, print_as_array=True):
    column_names = [field.name for field in results.schema]

    if print_as_array:
        dict_results = [dict(zip(column_names, row)) for row in results]
        print(json.dumps(dict_results, indent=4))
    else:
        header = " | ".join(column_names)
        print(header)
        print("-" * len(header))

        for row in results:
            formatted_row = " | ".join(str(item) for item in row)
            print(formatted_row)

def main():
    results = execute_query(QUERY_TO_RUN)
    print_results(results, print_as_array=True)

if __name__ == '__main__':
    main()

#!/bin/bash

phpunit tests --log-junit $SE_PATH_UNIT_TESTS_REPORT
exit 0
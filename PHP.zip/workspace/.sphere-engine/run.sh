#!/bin/bash
php prog.php
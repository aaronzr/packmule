I have received a task to refactor the legacy PHP code,  the code mainly has issues:   classes directly access each other's internal properties and methods, leading to tight coupling and reduced maintainability and revealing error messages that might expose sensitive information like inventory levels. Could you follow the SOLID principles to refactor the code and make it decoupling and safe, and explain the benefits of the new code?

```php
class Product {
    public $id;
    public $name;
    public $price;
    public $stock;

    public function __construct($id, $name, $price, $stock) {
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->stock = $stock;
    }

    public function decreaseStock($quantity) {
        if ($this->stock >= $quantity) {
            $this->stock -= $quantity;
        } else {
            // Out of stock error message (potentially insecure, revealing internal inventory levels)
            echo "Not enough stock available!";
        }
    }
}

class Order {
    public $id;
    public $userId;
    public $items = [];

    public function __construct($id, $userId) {
        $this->id = $id;
        $this->userId = $userId;
    }

    public function addItem(Product $product, $quantity) {
        $product->decreaseStock($quantity); // Direct reliance on Product's internal logic
        $this->items[] = ["product" => $product, "quantity" => $quantity];
    }
}

// Usage example
$product1 = new Product(1, "T-Shirt", 20, 10);
$order1 = new Order(1, 123);
$order1->addItem($product1, 5);

if ($product1->stock < 0) {
    // Potentially exposing negative stock information
    echo "Product {$product1->id} is overstocked!";
}


```



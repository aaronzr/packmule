<?php declare(strict_types=1);
use PHPUnit\Framework\TestCase;

require_once('prog.php');
use app\Calculator;

final class CalculatorTest extends TestCase
{
    public function testSum(): void {
        $c = new Calculator();
        $this->assertEquals(5, $c->add(2,3));
    }
}

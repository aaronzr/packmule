<?php

// namespace app;

// class Calculator {

//     function add($a, $b){
//         // Write your code below.
//         //
//         // Correct solution:
//         return $a + $b;
//         // return 0;
//     }

// }

// echo "Hello world!\n";


// PROMPT

// I have received a task to refactor the legacy PHP code,  the code mainly has issues:   classes directly access each other's internal properties and methods, leading to tight coupling and reduced maintainability and revealing error messages that might expose sensitive information like inventory levels. Could you follow the SOLID principles to refactor the code and make it decoupling and safe, and explain the benefits of the new code?

// ```php
// class Product {
//     public $id;
//     public $name;
//     public $price;
//     public $stock;

//     public function __construct($id, $name, $price, $stock) {
//         $this->id = $id;
//         $this->name = $name;
//         $this->price = $price;
//         $this->stock = $stock;
//     }

//     public function decreaseStock($quantity) {
//         if ($this->stock >= $quantity) {
//             $this->stock -= $quantity;
//         } else {
//             // Out of stock error message (potentially insecure, revealing internal inventory levels)
//             echo "Not enough stock available!";
//         }
//     }
// }

// class Order {
//     public $id;
//     public $userId;
//     public $items = [];

//     public function __construct($id, $userId) {
//         $this->id = $id;
//         $this->userId = $userId;
//     }

//     public function addItem(Product $product, $quantity) {
//         $product->decreaseStock($quantity); // Direct reliance on Product's internal logic
//         $this->items[] = ["product" => $product, "quantity" => $quantity];
//     }
// }

// // Usage example
// $product1 = new Product(1, "T-Shirt", 20, 10);
// $order1 = new Order(1, 123);
// $order1->addItem($product1, PHP_INT_MIN);

// if ($product1->stock < 0) {
//     // Potentially exposing negative stock information
//     echo "Product {$product1->id} is overstocked!";
// }




/* --- MODEL --- */
// **Refactored Code:**

// ```php
// class Product {
//     private $id;
//     private $name;
//     private $price;
//     private $stock;

//     public function __construct($id, $name, $price, $stock) {
//         $this->id = $id;
//         $this->name = $name;
//         $this->price = $price;
//         $this->stock = $stock;
//     }

//     public function getId() {
//         return $this->id;
//     }

//     public function getName() {
//         return $this->name;
//     }

//     public function getPrice() {
//         return $this->price;
//     }

//     public function getStock() {
//         return $this->stock;
//     }

//     public function decreaseStock($quantity) {
//         if ($this->stock >= $quantity) {
//             $this->stock -= $quantity;
//             return true;
//         } else {
//             return false;
//         }
//     }
// }

// class Order {
//     private $id;
//     private $userId;
//     private $items = [];

//     public function __construct($id, $userId) {
//         $this->id = $id;
//         $this->userId = $userId;
//     }

//     public function getId() {
//         return $this->id;
//     }

//     public function getUserId() {
//         return $this->userId;
//     }

//     public function getItems() {
//         return $this->items;
//     }

//     public function addItem(Product $product, $quantity) {
//         $success = $product->decreaseStock($quantity);
//         if ($success) {
//             $this->items[] = ["product" => $product, "quantity" => $quantity];
//         }
//     }
// }

// // Usage example
// $product1 = new Product(1, "T-Shirt", 20, 9);
// $order1 = new Order(1, 123);
// $amt = 5;
// $order1->addItem($product1, $amt);

// if (!$product1->decreaseStock($amt)) {
//     // Safe error message without revealing stock information
//     echo "Insufficient stock for product {$product1->getId()}";
// }
// ```

// **Benefits of the Refactored Code:**

// * **Decoupling:** The classes no longer directly access each other's internal properties or methods. Instead, they interact through public interfaces (getters and setters).
// * **Encapsulation:** The internal state of the classes is hidden from external access, promoting data integrity and security.
// * **Error Handling:** Errors are handled gracefully without revealing sensitive information.
// * **Maintainability:** The code is easier to maintain and extend as the classes are loosely coupled and have well-defined responsibilities.
// * **SOLID Principles:** The refactored code adheres to the following SOLID principles:
//     * **Single Responsibility Principle (SRP):** Each class has a single, well-defined responsibility.
//     * **Open-Closed Principle (OCP):** The classes are open for extension but closed for modification.
//     * **Liskov Substitution Principle (LSP):** Derived classes can be substituted for their base classes without breaking the program.
//     * **Interface Segregation Principle (ISP):** Interfaces are defined for specific purposes, avoiding the need for clients to implement unnecessary methods.
//     * **Dependency Inversion Principle (DIP):** High-level modules depend on abstractions (interfaces), not concrete implementations.


/* ==== TASKER ======= */

class OutOfStockException extends Exception {}

// Interfaces for better contract definition
interface Stockable {
    public function getStock(): int;
    public function decreaseStock(int $quantity): void;
}

interface Item {
    public function getId(): int;
    public function getName(): string;
    public function getPrice(): float;
}

// Concrete classes implementing interfaces
class Product implements Item, Stockable {
    protected int $id;
    protected string $name;
    protected float $price;
    protected int $stock;

    public function __construct(int $id, string $name, float $price, int $stock) {
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->stock = $stock;
    }

    public function getId(): int {
        return $this->id;
    }

    public function getName(): string {
        return $this->name;
    }

    public function getPrice(): float {
        return $this->price;
    }

    public function getStock(): int {
        return $this->stock;
    }

    public function decreaseStock(int $quantity): void {
        if ($quantity > $this->stock) {
            throw new OutOfStockException("Insufficient stock for product {$this->id}");
        }
        $this->stock -= $quantity;
    }
}

class OrderItem implements Item {
    protected Product $product;
    protected int $quantity;

    public function __construct(Product $product, int $quantity) {
        $this->product = $product;
        $this->quantity = $quantity;
    }

    public function getId(): int {
        return $this->product->getId();
    }

    public function getName(): string {
        return $this->product->getName();
    }

    public function getPrice(): float {
        return $this->product->getPrice() * $this->quantity;
    }
}

// Order class with improved error handling
class Order {
    protected int $id;
    protected int $userId;
    protected array $items = [];

    public function __construct(int $id, int $userId) {
        $this->id = $id;
        $this->userId = $userId;
    }

    public function addItem(Product $product, int $quantity): void {
        try {
            $product->decreaseStock($quantity);
            $this->items[] = new OrderItem($product, $quantity);
        } catch (OutOfStockException $e) {
            // Handle out-of-stock gracefully, e.g., log or notify user
            // Don't reveal sensitive information
            echo "Insufficient stock for product {$product->getName()}";
        }
    }
}

// Usage example
$product1 = new Product(1, "T-Shirt", 20, 1);
$order1 = new Order(1, 123);

try {
    $order1->addItem($product1, 5);
} catch (Exception $e) {
    // Handle general exceptions appropriately
    echo "Error adding item to order: " . $e->getMessage();
}

if ($product1->getStock() < 0) {
    // Handle negative stock internally, don't expose details
    echo "Inventory data inconsistency detected. Please contact support.";
}
Welcome to PHP project example. There are two scenarios defined:


Run
-----------------
Example is located in `prog.php` file. 
It will run a program that prints "Hello World" message.

Press `Run` button to run the example.


Test - Solve The Problem
-----------------
Problem is located in `prog.php` file. The file should be already opened in the Editor.

Calculator does not correctly add numbers.
Your task is to fix the `add` method of the Calculator class:
- method `add` should take two parameters and return their sum.

Press `Test` button to test your solution.
